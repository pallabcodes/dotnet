﻿namespace Synchronisation_1
{
    // Need to go through video 11 from 8:00
    class MainClass
    {
        // shared field/property for work result
        public static int result = 0;

        // lock handle for shared result
        private static object lockHandle = new object();

        // The default is Main Thread and others are Worker Thread

        #region ...
        // The Worker Threads will use this `AutoResetEvent` to ask if the `Main Thread` is ready to receive a new result. If it is not ready, the Worker Thread i.e. below will suspend.
        // so these are like even handler with suspend/wait
        public static EventWaitHandle readyForResult = new AutoResetEvent(false);
        public static EventWaitHandle setResult = new AutoResetEvent(false);
        #endregion

        public static void DoWork()
        {
            // This is an infinite loop
            while (true)
            {
                // 1. assign the value from result to variable i
                int i = result;

                // 3. simulate long calculation by sleeping for 1 milliesecond and then it repeats same 1, 2, 3 on next iteration
                Thread.Sleep(1);

                #region ...
                // wait until main loop is ready to receive result
                readyForResult.WaitOne();
                #endregion

                // 2. so, thread incrments the result field then it goes to step 3
                lock (lockHandle)
                {
                    result = i + 1;
                }

                #region ...
                // tell main loop that we set the result
                setResult.Set();
                #endregion
            }
        }

        public static void Main(string[] args)
        {
            // setup/create the thread with what needed to execute i.e. DoWork
            Thread t = new Thread(DoWork);
            t.Start(); // start the thread

            // 1. used "AutoResetEvent" to sync between/amongst threads
            // 2. when the thread i.e. actually providing the data has actual data available - it first needs to send a signal to the receiving thread that "it is ready to send data" (this could be easily implemented with `WaitOne` from AutoResetEvent) -> The providing thread (or Worker Thread in this case) then suspends itself, waiting for an answer -> The other thread (in this case receieve or main thread) i.e. waiting for the data, eventually reaches a points where it needs the data (from providing thread) -> Then (receieve thread) signals to the providing thread that it is ready to receive (by calling set on the same `AutoResetEvent`) -> now the providing thread wakes up knowing that the receiving thread(s) is ready to receieve data -> To ensure that the receiving thread(s) reads from shared variable only after the providing thread has written into the memory -> To do that we need another `AutoResetEvent` -> now, the receiving thread signals that it's waiting for the data by calling `WaitOne` on the second outer `AutoResetEvent` -> The receiving thread then suspends itself, waiting for the data to become available -> In the meantime, the providing thread has already writing to the shared variable and when it finishes it invokes the set method on the second AutoResetEvent to signal to the receiving thread(s) that the shared variable has been updated and is ready to be read -> The receiving thread(s) wake up, reads the shared variable and retrieves the data

            // This design provides a very robust communication channel between two threads that need to exchange data

            // Q: Are there any pre-built / native classes from .NET to help with syncing between/among threads ?

            // Answer: Task Parrallel Libary (TPL). This class is the backbone of asynchronous programming 

            // Q: so, how would you make two threads exchange data  with the Task class ?

            // with the Task class, there is no need for AutoResetEvent and Synchrnoisation variables for "critical sections", The Task class will do all of these internally.




            // collect result every 10 milliseconds
            for (int i = 0; i < 100; i++)
            {
                #region ...
                // This will indicate to the `Worker thread` that the `Main Thread` ready to receive the data
                readyForResult.Set();
                #endregion

                #region ...
                // wait until thread has set the result
                setResult.WaitOne();
                #endregion

                lock (lockHandle)
                {
                    Console.WriteLine(result);
                }

                // simulate other work
                Thread.Sleep(10);
            }

            // messy abort
            t.Abort();
        }
    }
}
