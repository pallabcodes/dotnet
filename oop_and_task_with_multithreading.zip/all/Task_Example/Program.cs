﻿namespace Task_Example
{
    class MainClass
    {
        public static void Main(string[] args) {
            // Below will create a new Task and immediately start in the `background`
            // As seen below, Task takes a generic argument i.e. string and as seen below Task retuns a string
            // StartNew expects a single argument i.e. a function delegate that must return a string value since since Task<string>
            var task = Task<string>.Factory.StartNew(() => {
                Thread.Sleep(1000);
                return "Mark";
            });

            // so, this Main programs starts 

            // 1. it runs the new task above 
            // 2. then immediately continutes down below code then write the name to the console then accesses the result of the task

            // Now, there is neither AutoResetEvent nor synchronisation field and neither WaitOne or Set method

            // Q: What would happen if Main program asks for the result before task is ready ?
            // Answer: The result value (the fallback or default value of the datatype or just null) 

            // Summary:

            // 1. With `Task` , no need to worry about "synchronisation and shared variable locking"
            // 2. Just define the work needs to be done through a lambda expression using the Task class
            // 3. Create and start the task and then access the result whenever needed
            // 4. The result property automatically blocks until the data is available

            // N.B: so, creating 100/1000 of Tasks are no problem at all, Even millions of tasks is possible if handle carefully

            Console.Write("Your name is");
            Console.Write(task.Result); // retrieves the task.Result and display it on the console without waiting if the task is finished or not (since it is backgroundn thread)
            // put a debugger on the next curly braces and it will open the defintion of result property
        }
    }
}
