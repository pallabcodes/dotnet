﻿namespace Lock_Statement_2
{
    class MainClass
    {
        private static int value1 = 1;
        private static int value2 = 1;

        // IMPORTANT: syncObject should always be "private", another Thread could also lock on that same field, now suddenly you have an unexpceted dependency between two threads that might lead to both `Threads locking` and waiting for each other. But when you lock on a Unique private that you create specifically for the occassion, then you `prevent any other Thread to lock on that same object` -> thus unexpected dependancy between threads can never happen (This is just another safety net to prevent unexecpted results)
        private static object syncObject = new object();

        // This is what compiler produces when used `lock` statement (refer to Lock_Statmenet project program.cs)
        public static void DoWork2()
        {
            // Below variable acts as a signal to finally block for releasing / exiting the `Thread`
            bool lockTaken = false;

            try
            {
                // so `lock` is nothing more than a call to Monitor class and it provides access to "critical sections"
                // so, Enter method enters a "critical session"
                // if unable to enter within 50ms then true else false thus timeout error will be thrown
                #region Monitor.TryEnter
                Monitor.TryEnter(syncObject, TimeSpan.FromMilliseconds(50), ref lockTaken);
                #endregion

                if (value2 > 0)
                {
                    Console.WriteLine(value1 / value2);
                    value2 = 0;
                }
            }
            finally
            {
                // so, Exits method exits a "critical session"
                // so, for some reason, if enter crititcal season, but not or unable to exist, then having an explicit signal or propertly like this `lockTake` is very helpful
                if (lockTaken) { Monitor.Exit(syncObject);  }
            }

        }
        public static void Main(string[] args)
        {
            Thread t1 = new Thread(DoWork2);
            Thread t2 = new Thread(DoWork2);
            t1.Start();
            t2.Start();
        }
    }
}