﻿namespace Race_Conditions
{
    class MainClass
    {
        public static int i = 0;
        public static void DoWork()
        {
            //for (int i = 0; i < 5; i++)
            //{
            //    Console.Write("*");
            //}

            // now using the global static property
            for (i = 0; i < 5; i++)
            {
                Console.Write("*");
            }
        }
        public static void Main(string[] args)
        {
            // start (an explicit separate) thread to print star 5 times
            Thread t = new Thread(DoWork);
            t.Start();

            // Display 5 additional stars (it will be executed on the main/default thread)
            DoWork();

            // so, this will output total 10 starts like ********** (5 from separate thread and another 5 from main thread)

            // but, when used global int property it prints ****** as now both threads are accessing and incrementing same variable from memory so instead of couting from 0 to 5, the loops are actually counting from 0 to 5 in steps of two and so the result of this is that only 5 or 6 stars are printed instead of expected 10. And this is a classic example of something called "Race condition" -> Two threads are fighting for same variable and as a result, the code starts to behave in "unpredictable ways like here it prints 6 stars which is basically maybe main thread has iterated 2 times then switches to separate thread and since it uses same variable from memory it simply iterates till reached the stop condition thus resulting to 5 or 6 stars instead of 10" -> The solutiuon to this "Race condition is `Locking Threads`"

        }
    }
}