﻿using System;
using System.Threading;

namespace Thread_Example_1
{
    class MainClass
    {
        private const int REPEATITIONS = 100;

        public static void DoWork()
        {
            for (int i = 0; i < REPEATITIONS; i++)
            {
                Console.Write("B");
            }
        }

        public static void Main(string[] args)
        {
            // start a new method using the Thread class constuctor i.e. new Thread(....) and it expects a ThreadStart delegate as an argument e.g new ThreadStart(.....) and `DoWork` is the method that the new Thread is responsible to run
            // Thread will run the single method `DoWork` and when it has done executing the method, the thread will automatically end and once ended, the thread cannot restart.

            // so, in this below example Thread runs this single method `DoWork` and within this method a for loop is being run (so the new thread executes this loop 1000 times as instructed within loop and simply display the letter B 1000 times). But at the same (the default)
            // Thread t1 = new Thread(new ThreadStart(DoWork));
            // t1.Start();

            // However, we don't need to explictly specify the ThreadStart delegate by using #region like below

            //#region start new thread without specifying ThreadStart
            //Thread t2 = new Thread(DoWork); // most accurate result as intended
            //t2.Start();
            //#endregion

            // This could be even further simplified using lambda
            #region start new thread without specifying ThreadStart
            Thread t3 = new Thread( () => { DoWork(); }); // instead of ThreadStart now it has anonymous delegate
            t3.Start();
            #endregion


            // now, below main thread is also running :: executing this loop here and displaying the letter "A" 1000 times ::
            for (int i = 0;i < REPEATITIONS;i++) { Console.Write("A"); }

            // The OS runs a given thread (whether created or default) for a while and then suspends it and runs a different thread (which is why it is known or refered to `juggling` and each time interval is known as "time slice" which is maximum time a thread could uninterupted) and so it will start working and print B a few times and then switch to another thread (here i.e. default thread) and prints A so BBBBBBBBBBBBBBBBAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABBBBBBBBBBB

            // Modern computers have multi-core processors that can actually run several threads at once but at any given time there are hunders of threads in an os i.e. many more than its available number of CPU cores. So, there's always a certain amount time slicing going on.
        }
    }

}

