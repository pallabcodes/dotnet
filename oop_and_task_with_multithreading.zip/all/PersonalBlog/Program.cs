using Amazon.DynamoDBv2;
using Amazon.DynamoDBv2.DataModel;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using PersonalBlog.Interfaces;
using PersonalBlog.Strategies;

var builder = WebApplication.CreateBuilder(args);

builder.Services.Configure<CookiePolicyOptions>(options => { options.CheckConsentNeeded = context => true; });

ConfigureServices(builder.Services);
ConfigureDataServices(builder.Services);

var app = builder.Build();

app.UseRouting().UseStaticFiles().UseCookiePolicy().UseAuthorization();

app.MapDefaultControllerRoute();

app.Run();

// We can't have one HttpClient per request or per thread because soon you will something called a socket congestion which means that because every server has only like 1020 view and limited number of socket connections available soon you run out of available sockets and then it will return 503 (service unavaialble type of response). So, another reason for using Singleton is that you will only have one socket open for entier application's lifecycle 


// This method gets called by the runtime. Use this method to add services to the container 
void ConfigureServices(IServiceCollection builderServices)
{
    builderServices.AddControllers();
    builderServices.AddRazorPages();
    builderServices.AddSingleton<IHttpContextAccessor, HttpContextAccessor>();
    builderServices.AddScoped<IAuthorizer, IpBasedAuthorizer>();
    builderServices.AddScoped<ProtectorAttribute>();
    builderServices.AddLogging(c => c.AddConsole());
}

void ConfigureDataServices(IServiceCollection serviceCollection)
{
    var client = new AmazonDynamoDBClient();
    var context = new DynamoDBContext(client);
    serviceCollection.AddSingleton<IDynamoDBContext>(context);
    //serviceCollection.AddScoped<IDataService, DynanmoDbDataService>();
    serviceCollection.AddScoped<IDataService, SqlServerDataService>();
}