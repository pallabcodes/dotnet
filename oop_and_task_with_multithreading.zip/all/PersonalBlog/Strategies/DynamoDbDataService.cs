﻿using PersonalBlog.Interfaces;
using PersonalBlog.Models;

namespace PersonalBlog.Strategies
{
    public class DynamoDbDataService : IDataService
    {
        public Task Create(Post model)
        {
            throw new NotImplementedException();
        }

        public Task<List<Post>> GetAll()
        {
            throw new NotImplementedException();
        }
    }
}
