﻿using System;
using Amazon.DynamoDBv2.DataModel;

namespace PersonalBlog.Models
{
    [DynamoDBTable(tableName: "post")] // This tell DynmaoDB the genrated ID below  is the hash key so we can use it as :DynamoDB hashkey
    public class Post
    {
        
        public Post()
        {
            Id = Guid.NewGuid().ToString();
        }

        [DynamoDBHashKey]
        public string Id { get; set; }
        public DateTime PostDateTime { get; set; }
        public string Title { get; set; }
        public string Content { get; set; }
    }
}
