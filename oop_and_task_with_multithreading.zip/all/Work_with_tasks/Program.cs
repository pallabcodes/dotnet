﻿namespace Work_with_tasks
{
    class MainClass
    {
        public static void Main(string[] args)
        {
            // start a new Task and it will run on a (default) background thread and by default a Task executes on the default .NET runtime thread pool
            // For a long running task, use `LongRunning` to execute the `Task` on a non-pull thread
            // Any exceptions thrown by a task will propagate to the calling/receiving code and automatically re-thrown in the wait method and result property.
            var task = Task.Factory.StartNew(() =>
            {
                Thread.Sleep(2000);
                Console.WriteLine("Hello World");

                #region thread information

                // check below if the current thread is a background thread
                Console.WriteLine("Is background thread: {0}", Thread.CurrentThread.IsBackground);

                // check below if the current thread is a thread in the runtime thread pool
                Console.WriteLine("Is threadPool thread: {0}", Thread.CurrentThread.IsThreadPoolThread);
                #endregion


                // throw an exception
                //#region throw exception
                //throw new InvalidOperationException("Something went wrong");
                //#endregion

            }, TaskCreationOptions.LongRunning); // this tells Task.Factory that it'll be a long running task that should not be executed on the default thread pool. 

            // now, the thread still runs on (default) background thread, but the thread is not part of the (default) thread pool due to use of `TaskCreationOptions.LongRunning`

            // so, in case of a long running operation or task is interacting with external systems and blocking on an IO call, then make sure to use always the `LongRunning` value as second above like above.

            // wait for task to complete
            // N.B: in case of exception, it propagates to the code receiving the data
            task.Wait();
            // add debugger on the exact below curly brance
        }
    }
}