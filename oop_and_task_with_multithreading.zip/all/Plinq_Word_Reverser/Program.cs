﻿namespace Plinq_Word_Reserver
{
    class MainClass
    {
        public static void Main(string[] args)
        {
            string sentence = "the quick brown fox jumped over the lazy dog";

            var words = sentence.Split()
                .AsParallel()
                // PLing by default doesn't follow an order during execution (so if needed order use as below)
                .AsOrdered()
                // without below method PLink will decide whether to use `parallelism or fallback to sequential` on its own
                .WithExecutionMode(ParallelExecutionMode.ForceParallelism)
                .Select(word => new string(word.Reverse().ToArray()));
            
            Console.WriteLine(string.Join(" ", words));
        }
    }
}