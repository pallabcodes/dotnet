﻿using System.Diagnostics;
using System.Text;

namespace Word_Reserver
{
    class MainClass
    {
        private static List<Task<string>> tasks = new List<Task<string>>();
        private static string ReverseString(string s)
        {
            Thread.Sleep(1000);
            StringBuilder sb = new StringBuilder();
            for (int i = s.Length - 1; i >= 0; i--)
            {
                sb.Append(s[i]);
            }

            return sb.ToString();
        }
        public static void ProcessSentence(string sentence)
        {
            // 1. The sentence has been split into words and iterates
            // 2. When iterating on each word, creates a new Task which reverses words with a trailling comma. Now, normally when you start a task inside another running task, you simply create an unconnected task that runs on its own. But when provided this setting (TaskCreationOptions.AttachedToParent) then created Task gets attached to its parent task (i.e already running) -> So, then the new Task will be a child Task of an already running parent Task -> And the Parent Task will only be completed only after all of their child tasks have completed -> So, off course, this extends theh runtime of the parent task until every child has finished reversing their word -> There is alos used `TaskCreationOptions.LongRunning` to assing a new Thread to each task `instead of using the thread pool to execute the tasks`
            // 3. If used TaskCreationOptions.None , then Parent task will be completed, then child tasks will be completed, so parent is not dependannt onn the comppletion of child tasks
            foreach (string word in sentence.Split())
            {
                tasks.Add(Task<string>.Factory.StartNew(() => ReverseString(word) + " ", TaskCreationOptions.AttachedToParent | TaskCreationOptions.LongRunning));
            }
        }
        public static void Main(string[] args)
        {
            string sentence = "the quick brown jump over the lazy dog";

            Stopwatch sw = new Stopwatch();

            sw.Start();
            Task.Factory.StartNew(() => ProcessSentence(sentence)).Wait();
            sw.Stop();
            Console.WriteLine("Total runtime: {0}ms", sw.ElapsedMilliseconds);

            #region verify that all tasks have completed
            for (int i = 0; i < tasks.Count; i++)
            {
                Console.WriteLine("Task {0} complete: {1}", i, tasks[i].IsCompleted);
            }
            #endregion



            // display result
            Console.Write("Result: ");
            foreach (Task<string> t in tasks) Console.WriteLine(t.Result);
        }
    }
}