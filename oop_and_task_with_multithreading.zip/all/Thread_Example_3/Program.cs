﻿namespace Thread_Example_3
{
    class MainClass
    {
        public static void Main(string[] args)
        {
            // start background thread using lambda expression instead of using ThreadStart class (as below)

            // N.B: By default any created threds (as below) runs on a foreground thread and foreground threads keep the application alive for as long as any one of them is running. Whereas once all the foregound threads finish, the application ends so if there are any backgound threads are running at this point will abruptly terminate. You can query or change a threads background status by using the `isBackground` property
            Thread t = new Thread(() =>
            {
                Console.WriteLine("Thread is starting, press enter to continue....");
                Console.WriteLine();
            });

            // t.IsBackground = true; // this is how to mark it as a background thread
            t.IsBackground = false;
            t.Start();

            // so, if used `Background` thread the moment it switches to main thread (which by default runs on Foreground thread) and it has no code to execute so it says (ok, anything to run here , none so leave and if there are any ongoing background tasks going on or pending , I don't care so as foreground task terminates it also terminates background tasks) so turning it into "Foreground" will solve the problem as it will wait to resolve all the pending tasks then terminates

            // Important: An application can't end / terminate until all of the "Foreground Tasks are done executing"

            // main program ends here

        }
    }
}