﻿namespace Thread_Example_2
{
    class MainClass
    {
        private const int REPEATITIONS = 10;

        public static void DoWork()
        {
            for (int i = 0; i < REPEATITIONS; i++)
            {
                Console.Write("B");
            }
        }

        public static void Main(string[] args)
        {
            // start 10 (named) new threads
            

            for (int i = 0; i < 10; i++)
            {
                Thread t = new Thread(new ThreadStart(DoWork));
                t.Name = "Thread" + i.ToString(); // You can set a thread name just once which is why it is useful for debugging and checking the "Thread Window"
                t.Start();
            }

            // add a breakpoint to nextline
            int dummy = 123;
        }
    }
}