﻿namespace Lock_Statement
{
    class MainClass
    {
        // Shared private fields
        private static int value1 = 1;
        private static int value2 = 2;

        // Synchronization object

        #region synchronisation object
        private static object syncObj = new object(); // can be any datatype
        #endregion


        // thread work method

        public static void DoWork()
        {
            // with `lock` the below execution of code will be Thread-Safe (so now it can be safely called from multiple threads simultanreously :: wrong word rather now multiple threads can executed during as OS switches from one Thread to Another without unexpected results or crashing)
            // So, `lock` statement is a synatactic sugar which basically means C# compiler will actually expand the statment to larget block of code, and `lock` is simply a conveniance provided by the compiler
            lock (syncObj)
            {
                if (value2 > 0)
                {
                    Console.WriteLine(value1 / value2);
                    value2 = 0;
                }
            }



        }

        public static void Main(string[] args)
        {
            // start two threads that executes same thing i.e. DoWork
            Thread t1 = new Thread(DoWork);
            Thread t2 = new Thread(DoWork);
            t1.Start();
            t2.Start();
        }
    }
}