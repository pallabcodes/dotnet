﻿using Microsoft.Extensions.DependencyInjection;

// Microsoft.Extensions.DependencyInjection will give access to IServiceCollection

IServiceCollection collection = new ServiceCollection();

//  # REGISTER DEPENDENICES

// AddScoped takes in 2 type arguments, 1) interface 2) interface maps to which concrete class
collection.AddScoped<IDataAccess, DataAccessMySql>(); // now, anywhere within the program come across `IDataAccess`, .NET will give data from / access to to `DataAccessMySql` class

// Everytime anywhere in the code we come across `IBusiness`, .NET automatically will give us "an instance of `Business` class"
collection.AddScoped<IBusiness, Business>(); // now, anywhere within the program come across `IBusiness`, .NET will give data from / access to to `Business` class

// now, `UserInterface` class doesn't implement any interface, so just Register the class directly like below
collection.AddScoped<UserInterface>();

// # Till now, just registered the dependencies but to use them, use the `IServiceProvider` and do it as below

// with the below syntax, all the registered interface with their classes from within `collection` will be created (which is why new keyword is needed to use explicity)
IServiceProvider provider = collection.BuildServiceProvider(); // once again, this will create all the concrete from within collection into actual data (i.e. equivalent to using new keyword)



// Before adding the "Micorsoft.Extensions.DependencyInjections" (and since DI above so no need to manually do it as below)
// IDataAccess da = new DataAccessMySqlServer();
// IBusiness biz = new Business(da);

 // UserInterface ui = new UserInterface(biz); // without DI
 UserInterface ui = provider.GetService<UserInterface>(); // IMPORTANT: I know wherever an interface used and if the interface is registered for DI (like this interface is); then it will give access to instance of associated class) -> which is why even though this class expects an argument for DI but that is not needs to be provided here since it has been already provided within the constructor of this class
// ui.Signup();

// # Ways to register DI

// 1. Singleton: Throughout the lifecycle of applicatoin, the instance will be created only once and reused therefater

// 2. AddScoped: The lifetime of the object (i.e. registered with this way), it is about the lifetime of the request. Everytime the user visits a new page in an ASP.NET core mvc app, or every time the user hits a restful API -> that is a new request (which is what meant here) and so for every request, a new scoped object will be created and every time the object is injected, a new instance will be created therefore.
// N.B: e.g. everytime you visit a new page, that will off course result to a new request and if you have different threads inside the request that object will be shared amongst all the threads -> Therefore it is okay for MVC but not for Multi-Threading

// 3. AddTransient: Different instance everytime Object is requested or injected so everytime the object is injected, a new instance will be created regardless of whether it's in a new thread or it's in a new request e.g. forEach loop where if used "Transient" a new object will be created in each iteration
// N.B: Everytime a new instance is injected and suitable for multi-threading



// everytime we seen an interface called Logger What I want is an Object of type Logger (class)
// a class doesn't create an Object on its own (it only contains metadata or implements metadata as per interface) : only when new used the Object is created based on the metadata i.e. class

public class UserInterface
{
    // accessor [keyword] returntype [property/method/clss) 
    private string _username;
    private string _password;

    private IBusiness _business;

    // IMPORTANT: I know wherever an interface used and "if the interface is registered for DI e.g. `IBusiness`"; then .NET will automatically/internally give access to instance of associated class i.e. here `Business`)++

    public UserInterface (IBusiness business) { _business  = business; }

    private void GetData()
    {
        Console.Write("Enter username:");
        _username = Console.ReadLine();

        Console.Write("Enter password:");
        _password = Console.ReadLine();
    }

    public void Signup()
    {
        GetData();
        _business.Signup(_username, _password);
    }

}

public interface IBusiness
{
    void Signup(string userName, string password);
}

// Business class implements the interface i.e. IBusiness
public class Business : IBusiness
{
    private IDataAccess _dataAccess;

    public Business (IDataAccess dataAccess) { _dataAccess = dataAccess; }

    public void Signup(string userName, string password)
    {
        _dataAccess.Signup(userName, password);
    }
}

public interface IDataAccess
{
    void Signup(string userName, string password);
}

public class DataAccessSqlServer : IDataAccess
{
    public void Signup(string userName, string password)
    {
        // use EF to write data into SQL server
    }
}

public class DataAccessMySql : IDataAccess
{
    public void Signup(string userName, string password)
    {
        // use EF to write data into SQL server
    }
}