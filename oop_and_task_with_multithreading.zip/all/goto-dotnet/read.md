> c# interface is to be used to hold contracts i.e. methods
>
> LINQ and THREADS are skipped for now

```c#
// C# Struct Example
public struct Person
{
    public string Name;
    public int Age;

    public void Introduce()
    {
        Console.WriteLine($"Hello, my name is {Name}, and I'm {Age} years old.");
    }
}

// C# Interface Example
public interface ISpeaker
{
    void Speak();
}


```
> c# struct is to be used to contain fields/properties only
> 
> 
## .NET confusion: .NET framework (4.8) vs .Net core(3.4) vs .Net standard vs .Net vs C#

1. .NET Framework (4.8) is a platform first and foremost to run .NET environment supported languages (c#, f#, vb.net, xamarin etc.), 
2. [ISSUE]: However .NET Framework is designed specifically for Windows and cannot run natively on other operating systems.
   So,
   this framework itself not cross-platform
   (so to work, deploy and use it must be a Windows server or machine off course)   
3. [SOLUTION]: So, to bring in cross-platform, `.NET core (3.4)` is introduced
4. [Successor]: .NET core (3.4) -> next version named .NET 5 to reflect that it is the successor and defacto standard (and since .NET framework and .NET code 3.4 by skipping version 4 it made sense to refer that .NET 5 is new standard/successor for both and to make this version more readable and easy to differentiate, `Microsoft decided to name it .NET 5 dropping the core word` -> `so once again .NET 5 just successor i.e. newer version .NET core 3.4`) so off course after .NET 5 and it will .NET 6 (not .NET core 6)
5. [.NET STANDARD]: 

## What is .NET Framework and what it does?

1. **Code Writing**: Developers write code in a .NET-supported language such as **VB.NET**, **C#**, or **F#**.

2. **Compilation to Intermediate Language (IL)**:
    - The source code is compiled into **Common Intermediate Language (CIL)** (formerly known as Microsoft Intermediate Language or MSIL) by the language-specific compiler (e.g., `csc.exe` for C#).
    - The output of this compilation is an **assembly**, typically a `.dll` or `.exe` file.

3. **Execution Using Common Language Runtime (CLR)**:
    - The CLR is the runtime environment in the .NET Framework that handles execution. It provides services such as memory management, garbage collection, and exception handling.

4. **Just-In-Time (JIT) Compilation**:
    - When the application runs, the CLR uses the **Just-In-Time (JIT)** compiler to convert the CIL code into **native machine code** specific to the host operating system and processor architecture.
    - The CPU then executes this machine code.

5. **Execution and Optimization**:
    - During execution, the CLR performs optimizations like inlining and caching frequently used methods.
    - Managed code is run within the CLR, ensuring security and robustness.



## From source code to machine code

1. Code Written in a .NET Language
   Developers write code in a .NET-supported language (e.g., C#, VB.NET, F#).

2. Compilation:
   The source code is compiled by a language-specific compiler (e.g., csc for C#) into Intermediate Language (IL).
   The compiled IL is stored in an assembly, which can be either:
   .exe: A standalone executable file.
   .dll: A library file, meant to be used by other applications.
   This assembly is not machine code yet; it is platform-independent IL code.

3. Execution by the Common Language Runtime (CLR):
   When the program is executed:
   The CLR loads the assembly (.dll or .exe) containing the IL code.
   The CLR uses the Just-In-Time (JIT) Compiler to convert the IL code into native machine code specific to the operating system and CPU.
   The CPU executes the native machine code.




- ASP.NET with dependency injection: [repo] https://github.com/aussiearef/DependencyInjectionV3/tree/master/AddKeyMethods

- A #C sharp program starts in a single thread created automatically by the framework and operating system, this thread is called "main thread" -> A program turns "multithreaded" by creating additional threads

- Each running `Thread` gets its own stack, so all local variables are kept strictly separate


- Why Locking or Locking Threads needed?

```
int i = 0;
private void DoWork() { i++; } 
```

- What actually happens when `DoWork` invoked ? And why it returns 1 even if it ran by a separte thread

1. Read current value of i
2. Add +1 to i
3. write the result into the memory of i


Suppose, There are 2 threads (default and separate executing `DoWork` method) , Refer to the image for clarity 

- Assume Thread 1 is default and Thread 2 is a separat thread

- Thread 1 executes step 1 and step then OS interupts the Thread 1 and switches over to Thread 2 (NOTE: as OS switches to THREAD 2 N.B: At this (in memory and before switching Thread 1 didn't write to memory)  so i is still 0 in memory so) and executes all 3 steps -> since written to memory so now, variable i has become 1 in memory -> Thread 2 ends and OS switches back to Thread 1 and then within Thread 1 it executes the reamining task or step (i.e. writing to result of incrementation to memory) which is again the value so now the variable i has value 1 written in the memory , Thread 1 ends.
- So, i in memory contains 1 despite the face that it literally has been incremented twice

-> This is called "Race condition" and to solve it "Locking or Locking Threads" used

-> And it happens because incrementing the variable is not atomic operation, since it can be interupted halfway leading to unexpected results



# Solution: Locking Threads , refer to the image for clarity

- Now, a section of code that cannot be interupted by another thread is known as "critical section"
- A piece of code that a Thread can execute at a time
- So, if a given Thread is executing a piece of code then other Thread must wait for the current thread to finish
- Having other Threads wait while a current single thread is executing. A critical section is known as `Thread Locking`

# So, When should you Lock Threads ?

- When two or more threads are reading and writing to the same shared variable
- This will eliminate 99% race conditions from the code


# Thread Synchronisation with AutoResetEvents (act of Synchronising two or more threads together in order for them to exchange data)

Thread Synchronisation is  act of suspending one Thread until a certain condition is met in another Thread

Refer to the image for clarity i.e. thread_sync

- So, the Main thread that launches the separate/second Thread to do some complex work in the background
- The separate/second thread loops and produces a new result every few millieseconds 
- The main thread simply waits for the results to become available and picks them up one by one 

N.B: Now, I already know how to set up a shared variable to pass data between threads and while avoiding a race condition. So, ensure to lock the variable whenever it is being read or written to.



- Amy exception thrown by a child's task bubbles up to the parent and gets rethrown

https://www.youtube.com/watch?v=uFk0mgljtns
https://www.reddit.com/r/premiere/comments/18wdeul/what_adobe_software_should_i_learn_to_use_to/