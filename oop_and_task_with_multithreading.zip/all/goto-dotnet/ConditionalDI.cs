﻿using Microsoft.Extensions.DependencyInjection;


interface ITaxCalculator
{
    int Calculate();
}


namespace ConsoleApp1
{
    class ConditionalDI
    {
        public static void Main(string[] args)
        {
            Console.Clear();

            var collection = new ServiceCollection();

            collection.AddScoped<EuropeTaxCalculator>();
            collection.AddScoped<AustraliaTaxCalculator>();

            // # condtionally resolving a dependency

            // The condition to use and then what it returns is a `ITaxCalculator`
            // AddScoped<condition, concrete class or condiation apply to which class> -> The first argument i.e. condition could be string, bool, int enum, interface or anything and 2nd argument is the "Returntype"
            collection.AddScoped<Func<UserLocations, ITaxCalculator>>(
                ServiceProvider => key =>
                {
                    // now, looking at what returns from cases, indeed something that matches `ITaxCalculator` or null as below
                    switch (key)
                    {
                        case UserLocations.Australia: return ServiceProvider.GetService<AustraliaTaxCalculator>();
                        case UserLocations.Europe: return ServiceProvider.GetService<EuropeTaxCalculator>();
                        default: return null;
                    }
                }

            );

            collection.AddScoped<Purchase>();

            var builder = collection.BuildServiceProvider(); // instantiating

            var purchase = builder.GetService<Purchase>(); // accessing an instance i.e. Purchase
            var totalCharge = purchase.Chcekout(UserLocations.Australia);

            Console.WriteLine(totalCharge);
            Console.Write("Press a key:");
            Console.ReadKey();
        }
    }
}


public class EuropeTaxCalculator : ITaxCalculator
{
    public int Calculate()
    {
        return 20;
    }
}

public class AustraliaTaxCalculator : ITaxCalculator
{
    public int Calculate()
    {
        return 10;
    }
}

public class Purchase
{
    private readonly Func<UserLocations, ITaxCalculator> _accessor; // this is a delegate

    public Purchase(Func<UserLocations, ITaxCalculator> accessor)
    {
        _accessor = accessor;
    }

    public int Chcekout(UserLocations location)
    {
        var tax = _accessor(location);
        var total = tax.Calculate() + 100;

        return total;
    }
}

public enum UserLocations { Europe, Australia }