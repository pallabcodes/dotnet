﻿using System.Collections.Concurrent;
using Microsoft.Extensions.DependencyInjection;

interface ICertificate
{
    DateTime DateOfBirth { get; set; }
}

namespace ConsoleApp1
{

    class Example
    {
        static void Main(string[] args)
        {
            // A class should have a single responsiblity i.e. Single Responsibility Principle 

            // Resposibility: below `ServiceCollection` has a single responsibility of "containtaing metadata and mapping of types"
            var collection = new ServiceCollection();

            collection.AddScoped<ClassWithStaticProperty>();

            // Responsibility: Here, created an instance `ServiceProvider` and its reposiblity to creat instances and managing the lifetime of the instances
            var provider = collection.BuildServiceProvider();

            // Which is why `ServiceProvider` class doesn't handle the instantiation (then it will be handling 2 responsibilities)

            var instance = provider.GetService<ClassWithStaticProperty>();

            Console.WriteLine("Hello, World");
        }
    }

    class ClassWithStaticProperty
    {
        // Here, `PrimaryKeys` is a static property so neither AddScoped or AddTransient will do anything since, no matter how many instances are available it will use same `PrimaryKeys` from static 
        // And, List is not thread safe

        // so, ulimately if there are multiple threads, they will try to write to same (static) `PrimaryKeys` causing a race condition

        // Thus, regarless of how used DI for this, as it is now it won't work

        // SOLUTION: The issue arises due to using static a) so if the field doesn't need to be static, make it non-static b) otherwise, if static must be kept then use a Thread-Safe datatype insted of List

        // public static List<int> PrimaryKeys; // List is not Thread-Safe

        public static ConcurrentBag<int> PrimaryKeys; // Kind of Similar to the List but Thread-Safe so can be used as an alternative to List -> now, with this Thread-Safe datatype (DI could be done effectively)

        public void save() { }

    }

    class Employee
    {
        private readonly ICertificate _certificate;

        public Employee(ICertificate certificate)
        {
            _certificate = certificate;
        }

        public int EmployeedId { get; set; }

        public void save()
        {
            var dob = _certificate.DateOfBirth;
            // save to db later
        }
    }
}