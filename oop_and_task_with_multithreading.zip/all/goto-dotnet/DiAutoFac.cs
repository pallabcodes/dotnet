﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

// N.B: The third-party package `AutoFac` could be used for DI also to use when something i.e. not natively supported with .NET DI 

namespace ConsoleApp1
{
    internal class DiAutoFac
    {
    }
}
