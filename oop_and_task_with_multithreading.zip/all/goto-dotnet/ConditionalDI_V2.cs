﻿using Microsoft.Extensions.DependencyInjection;

var collection = new ServiceCollection();

// Important: Below could only be done using it like this through ServiceCollection and ServiceProvider (not aviable for mvc and minimal apis)

// Registering Dependencies

// The key could be any object but usually it is either an enum or string
collection.AddKeyedSingleton<ITaxCalculator, AustraliaTaxCalculator>(UserLocations.Australia);
collection.AddKeyedSingleton<ITaxCalculator, EuropeTaxCalculator>(UserLocations.Europe);

// creating instances for all registered dependencies within collection
var provider = collection.BuildServiceProvider();

// Accessing 
ITaxCalculator taxCalculatorForEur = provider.GetKeyedService<ITaxCalculator>(UserLocations.Europe);
// ITaxCalculator taxCalculatorForAus = provider.GetKeyedService<ITaxCalculator>(UserLocations.Australia);

Console.Clear();
Console.WriteLine($"Applicable tax rate is: {taxCalculatorForEur.Calculate()}");

Console.ReadKey();


