﻿using System;
using Microsoft.Extensions.DependencyInjection;
using System.Threading.Tasks;

internal class DIExample
{
    private static void Main(string[] args)
    {
        Console.Clear();

        var collection = new ServiceCollection();
        collection.AddScoped<Scoped>();
        collection.AddScoped<Transient>();

        var provider = collection.BuildServiceProvider();

        Parallel.For(1, 10, i =>
        {
            var scopedObject = provider.GetService<IServiceScope>();
            var trasientObject = provider.GetService<Transient>();

            Console.WriteLine($"Scope ID:{scopedObject.GetHashCode()}");
            Console.WriteLine($"Transient ID:{trasientObject.GetHashCode()}");
        });

        Console.Write("Press a key");
        Console.ReadKey();
    }
}

namespace ConsoleApp1 { }

public class Scoped { }

public class Transient { }

